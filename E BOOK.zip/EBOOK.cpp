#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
using namespace std;
void intro_code();
void display_topics();
int get_topic();
void second_topic();
void third_topic();
void fourth_topic();
void welcome_in(){
    cout << endl;
    cout << "*******************MY E Book***********************";
    cin.get();
    display_topics();
}

void display_topics(){
    cout <<"\n1:- Introduction to C++";
    cout <<"\n2:- Math time in C++";
    cout <<"\n3:- Classes in C++";
    cout << "\n4:- Inheritance in C++";    
    //cout << "\n5:- Exception Handlling in C++";
    cin.get();
    get_topic();
}

int get_topic(){
    cout <<"\nPlease enter the topic which you would like to study: ";
    int x; cin >> x;
    switch (x){
        case 1:
        cout <<"\nYou have chosen the first topic";
        cin.get();
        intro_code();
        break;
        case 2:
        cout <<"\nYou have chosen the second topic";
        cin.get();
        second_topic();
        break;
        case 3:
        cout <<"\nYou have chosen the third topic";
        cin.get();
        third_topic();
        break;
        case 4:
        cout << "\nYou have chosen the fourth topic";
        fourth_topic();
        break;
        default:
        cout <<"\nBailing out to Index again (INVALID INPUT)";
        cin.get();
        display_topics();
    }
}

void intro_code(){
    ifstream readOBJ;
    cout << "\nWelcome to c++ intro here is the Hello world code";
    cout<<"\n C++ is a general-purpose object-oriented programming (OOP) language, developed by Bjarne Stroustrup, and is an extension of the C language. It is therefore possible to code C++ in a C style or object-oriented style. In certain scenarios, it can be coded in either way and is thus an effective example of a hybrid language.";
    cout << endl;
    readOBJ.open("Intro.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    
    if (x == 1){
        cout <<"\nHello venky";
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
}

void second_topic(){
    ifstream readOBJ;
    cout << "\nWelcome to math module here are the subtopics";
    cin.get();
    string gety;
    readOBJ.open("mathtopic.txt");
    if(readOBJ.is_open()){
        while(!readOBJ.eof()){
            getline(readOBJ,gety);
            cout <<gety << endl;
        }
    readOBJ.close();
    cout << "\nEnter The topiv that you want to study: ";
    int x; cin >> x;
    if (x == 1){
    readOBJ.open("MT1.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    if (x == 1){
        int a ,b;
        cout <<"\nEnter two elements to add: ";
        cin >> a >> b;
        cout <<"\nThe sum is " << a+b;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }
    else if(x == 2){
    readOBJ.open("MT2.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    
    if (x == 1){
        int a ,b;
        cout <<"\nEnter two elements to substract: ";
        cin >> a >> b;
        cout <<"\nThe difference is " << a-b;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }   
    else if (x == 3){
            readOBJ.open("MT3.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    
    if (x == 1){
        int a ,b;
        cout <<"\nEnter two elements to Multiply: ";
        cin >> a >> b;
        cout <<"\nThe product is " << a*b;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }
    else if (x == 4){
            readOBJ.open("MT4.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    
    if (x == 1){
        float a ,b;
        cout <<"\nEnter two elements to devide: ";
        cin >> a >> b;
        cout <<"\nThe division is " << a/b;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }
    else if (x == 5){
            readOBJ.open("MT5.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    
    if (x == 1){
        float a;
        int b;
        cout <<"\nEnter two elements to get power: ";
        cin >> a >> b;
        while (b!=0){
            a *= a;
            b--;
        }
        cout <<"\nThe power is " << a;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }
    else{
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get(); 
    }
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
}

void third_topic(){
    ifstream readOBJ;
    cout << "\nWelcome to class module here are the subtopics";
    cin.get();
    string gety;
    readOBJ.open("classP.txt");
    if(readOBJ.is_open()){
        while(!readOBJ.eof()){
            getline(readOBJ,gety);
            cout <<gety << endl;
        }
    readOBJ.close();
    cout << "\nEnter The topiv that you want to study: ";
    int x; cin >> x;
    if (x == 1){
    readOBJ.open("CL1.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    if (x == 1){
        int a ,b;
        cout <<"\nEnter two elements to add & substract: ";
        cin >> a >> b;
        cout <<"\nThe Results are " << a+b << " & " << a-b;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }
    else if(x == 2){
    readOBJ.open("CL2.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    
    if (x == 1){
        int a ,b;
        cout <<"\nHello, world"<<endl;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }   
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
}

void fourth_topic(){
    ifstream readOBJ;
    cout << "\nWelcome to class module here are the subtopics\n";
    cin.get();
    string gety;
    readOBJ.open("IP.txt");
    if(readOBJ.is_open()){
        while(!readOBJ.eof()){
            getline(readOBJ,gety);
            cout <<gety << endl;
        }
    readOBJ.close();
    cout << "\nEnter The topiv that you want to study: ";
    int x; cin >> x;
    if (x == 1){
    readOBJ.open("IP1.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    if (x == 1){
        int a ,b;
        cout <<"\nEnter first no: ";
        cin >> a;
        cout <<"Enter second no: ";
        cin >> b;
        cout <<"\nThe Results are " << a+b;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }
    else if(x == 2){
    readOBJ.open("IP2.txt");
    string output;
    if(readOBJ.is_open()){
    while(!readOBJ.eof()){
        getline(readOBJ,output);
        cout << output<<endl;
    }
    readOBJ.close();
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }
    cout << "\nIf you want the output please press 1: ";
    int x; cin >> x;
    
    if (x == 1){
        cout << "A's constructor called" << endl;
        cout << "B's constructor called" << endl;
        cout << "C's constructor called" << endl;
    }
    else {
        cout <<"\nWrong input Bailing out to main menu";
        display_topics();
        cin.get();
    }
    exit(1);
    }   
    }
    else {
        cout <<"\nFile Not found exiting. Please add 'data' folder to use this proagram\n";
        exit(1);
    }    
}

int main()
{
    welcome_in();
}
